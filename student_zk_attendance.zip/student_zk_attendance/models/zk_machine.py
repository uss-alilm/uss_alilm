# -*- coding: utf-8 -*-
###################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#    Copyright (C) 2022-TODAY Cybrosys Technologies(<http://www.cybrosys.com>).
#    Author: cybrosys(<https://www.cybrosys.com>)
#
#    This program is free software: you can modify
#    it under the terms of the GNU Affero General Public License (AGPL) as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###################################################################################
import pytz
import sys
import datetime
import logging
import binascii
import datetime
from datetime import date, datetime, time

from . import zklib
from .zkconst import *
from struct import unpack
from odoo import api, fields, models, _
from odoo import _
from datetime import date, timedelta
from datetime import date, timedelta, datetime
import socket
_logger = logging.getLogger('biometric_device')

from pytz import timezone, all_timezones
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from zk import ZK
from zk.exception import ZKErrorResponse, ZKNetworkError
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError, UserError
from socket import timeout
from odoo.exceptions import ValidationError, UserError
from odoo import models, fields, api
from datetime import datetime, timedelta

_logger = logging.getLogger(__name__)
try:
    from zk import ZK, const
except ImportError:
    _logger.error("Please Install pyzk library.")

class ResourceCalendarAttendance(models.Model):
    _inherit = 'resource.calendar.attendance'

    is_student_shift = fields.Boolean(string='Student Shift', default=False)
class DepartmentStudents(models.Model):
    _name = 'student.department'

    name= fields.Char(string='Department Name')
    work_calendar_id = fields.Many2one('student.work.calendar', string='Work Calendar')
    manager_id = fields.Many2one('res.partner')
    
class StudentWorkCalendar(models.Model):
    _name = 'student.work.calendar'
    _description = 'Student Work Calendar'


    name = fields.Char('Calender Name')
    attendance_id = fields.Many2one('student.attendance', string="Attendance")
    hour_from = fields.Float(related='attendance_id.hour_from', string="Hour From", readonly=True)
    start_hour = fields.Char(string="Start Hour", required=True)  
    end_hour = fields.Char(string="End Hour", required=True) 
    hours_per_day = fields.Float(string="Hours per Day", compute='_compute_hours_per_day', store=True)
    calculated_hours = fields.Float(string='Calculated Hours', compute='_compute_calculated_hours', store=True)
    partner_id = fields.Many2one('res.partner',related='student_id', string='Student')
    student_id = fields.Many2one('res.partner', string='Student')
    attendance_ids = fields.One2many('student.attendance', 'work_calendar_id', string='Attendances')
    shift_early_checkin = fields.Float(string="Min Check-in (Min)", default=10)
    shift_after_checkout = fields.Float(string="Max Checkout (Min)", default=10)

    @api.depends('start_hour', 'end_hour')
    def _compute_hours_per_day(self):
        for record in self:
            try:
                if isinstance(record.start_hour, str) and isinstance(record.end_hour, str):
                    start_time = datetime.strptime(record.start_hour, "%H:%M").time()
                    end_time = datetime.strptime(record.end_hour, "%H:%M").time()
                    
                    # Calculate the difference in hours
                    total_seconds = (end_time.hour * 3600 + end_time.minute * 60) - (start_time.hour * 3600 + start_time.minute * 60)
                    hours_per_day = total_seconds / 3600
                    record.hours_per_day = hours_per_day
                else:
                    record.hours_per_day = 0.0  # أو قيمة افتراضية
                
            except (ValueError, TypeError):
                record.hours_per_day = 0.0  # قيمة افتراضية في حالة الخطأ

    @api.depends('start_hour')
    def _compute_calculated_hours(self):
        for record in self:
            record.calculated_hours = record.hours_per_day  
        
    partner_id = fields.Many2one('res.partner', string='Student')
    student_id = fields.Many2one('res.partner', string='Student') 

    shift_early_checkin=fields.Float(string="Min Checkin (Min)",default=10)
    shift_after_checkout=fields.Float(string="Max Checkout (Min)",default=10)

class ResPartner(models.Model):
    _inherit = 'res.partner'

    student = fields.Boolean(string='Is a Student', default=False)
    student_attendance_ids = fields.One2many('student.attendance', 'student_id', string='Student Attendances')
    work_calendar_id = fields.Many2one('student.work.calendar',related='department_id.work_calendar_id', string='Work Calendar')
    device_id = fields.Char(string="Device ID")
    device_name = fields.Many2one('zk.machine', string="Device Name")
    department_id = fields.Many2one('student.department', string='Department')

class StudentAttendance(models.Model):
    _name = 'student.attendance'
    _description = 'Student Attendance'


    hour_to = fields.Float(string="Hour To") 
    hour_from = fields.Float(string="Hour From")
    
    name = fields.Char(string='Attendance Name',  default='This is required Field')
    day_period = fields.Char(string='Day Period')
    employee_id = fields.Many2one('res.partner', string='Student Name',related='student_id', required=False)
    department_id = fields.Many2one('hr.department', string='Department', required=False)
    student_id = fields.Many2one('res.partner', string='Student', required=True, default=1)
    check_in = fields.Datetime(string='Check In')
    check_out = fields.Datetime(string='Check Out')
    duration = fields.Float(string='Duration', compute='_compute_duration', store=True)
    device_id = fields.Char(string='Biometric Device ID')
    is_process = fields.Boolean('is_process', default=False)
    shift_rec = fields.Many2one('resource.calendar.attendance', string='Shift Record')
    expected_check_in = fields.Float(string="Expected Check In")
    expected_check_out = fields.Float(string="Expected Check Out")
    act_diff_time = fields.Float(string='Overtime Time', readonly=True)
    work_address = fields.Many2one('res.partner', string='Address', compute='_compute_work_address')
    student_attend = fields.Boolean(string='Student Attend', default=False)
    work_calendar_id = fields.Many2one('student.work.calendar', string='Work Calendar')
    worked_hours = fields.Float(string='Worked Hours', compute='_compute_duration', store=True)

    dayofweek = fields.Selection(
        selection=[
            ('0', 'Monday'),
            ('1', 'Tuesday'),
            ('2', 'Wednesday'),
            ('3', 'Thursday'),
            ('4', 'Friday'),
            ('5', 'Saturday'),
            ('6', 'Sunday'),
        ],
        string='Day of Week',
    )

    @api.depends('check_in', 'check_out')
    def _compute_duration(self):
        for rec in self:
            if rec.check_in and rec.check_out:
                duration = (rec.check_out - rec.check_in).total_seconds() / 3600
                rec.duration = duration
                rec.worked_hours = duration

    @api.depends('device_id')
    def _compute_work_address(self):
        for rec in self:
            address = self.env['zk.machine'].search([('id', '=', rec.device_id)], limit=1)
            rec.work_address = address.address_field if address else False

    @api.constrains('check_in', 'check_out')
    def _check_validity_check_in_check_out(self):
        """ fix if check_out is earlier than check_in. """
        for attendance in self:
            if attendance.check_in and attendance.check_out:
                if attendance.check_out < attendance.check_in:
                    checkin=attendance.check_in
                    checkout=attendance.check_out
                    attendance.check_out=checkin
                    attendance.check_in=checkout

    @api.constrains('check_in', 'check_out', 'student_id')
    def _check_validity(self):
        for attendance in self:
            if attendance.check_in and attendance.check_out:
                if attendance.check_in > attendance.check_out:
                    raise ValidationError(_("Check-out time cannot be earlier than Check-in time."))


class ZkMachine(models.Model):
    _name = 'zk.machine'
    
    name = fields.Char(string='Machine IP', required=True)
    port_no = fields.Integer(string='Port No', required=True)
    address_id = fields.Many2one('res.partner', string='Working Address')
    address_field = fields.Many2one('res.partner',related='address_id', string='Working Address')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.user.company_id.id)
    log_by_check_in_check_out=fields.Selection([ ('check_in_out','Check in and Check out'),
                                                 ('check_first_last','First and Last')],string='Register By', default='check_first_last')
    period_gap=fields.Integer('Checkout (Gap) in Minutes',default='0')
    
    def device_connect(self, zk):
        try:
            conn = zk.connect()
            return conn
        except:
            return False
    
    def clear_attendance(self):
        for info in self:
            try:
                machine_ip = info.name
                zk_port = info.port_no
                timeout = 30
                try:
                    zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=False)
                except NameError:
                    raise UserError(_("Please install it with 'pip3 install pyzk'."))
                conn = self.device_connect(zk)
                if conn:
                    conn.enable_device()
                    clear_data = zk.get_attendance()
                    if clear_data:
                        # conn.clear_attendance()
                        self._cr.execute("""delete from zk_machine_attendance""")
                        conn.disconnect()
                        raise UserError(_('Attendance Records Deleted.'))
                    else:
                        raise UserError(_('Unable to clear Attendance log. Are you sure attendance log is not empty.'))
                else:
                    raise UserError(
                        _('Unable to connect to Attendance Device. Please use Test Connection button to verify.'))
            except:
                raise ValidationError(
                    'Unable to clear Attendance log. Are you sure attendance device is connected & record is not empty.')

    def getSizeUser(self, zk):
        """Checks a returned packet to see if it returned CMD_PREPARE_DATA,
        indicating that data packets are to be sent

        Returns the amount of bytes that are going to be sent"""
        command = unpack('HHHH', zk.data_recv[:8])[0]
        if command == CMD_PREPARE_DATA:
            size = unpack('I', zk.data_recv[8:12])[0]
            print("size", size)
            return size
        else:
            return False

    def zkgetuser(self, zk):
        """Start a connection with the time clock"""
        try:
            users = zk.get_users()
            print(users)
            return users
        except:
            return False

    @api.model
    def cron_download(self):
        machines = self.env['zk.machine'].search([])
        for machine in machines :
            machine.download_attendance()
    ###===========================================================================================================
    def get_time_from_float(self, float_type):
        str_off_time = str(float_type)
        official_hour = str_off_time.split('.')[0]
        official_minute = int(round(round(float("0." + str_off_time.split('.')[1]),5)*60))
        if official_minute==60:
            official_minute-=1
        str_off_time = official_hour + ":" + str(official_minute)
        logging.info("the TIme>>>="+str(str_off_time))
        str_off_time = datetime.strptime(str_off_time, "%H:%M").time()
        return str_off_time
    def _get_float_from_time(self, time):
        time_type = datetime.strftime(time, "%H:%M:%S")
        signOnP = [int(n) for n in time_type.split(":")]
        signOnH = signOnP[0] + signOnP[1] / 60.0+ signOnP[2]/3600
        return signOnH
    def subtract_two_times_24h(self, time_from,time_to):
        t1=str(self.get_time_from_float(time_from))
        t2=str(self.get_time_from_float(time_to))
        c1hour=int(t1.split(":")[0])
        c1minute=int(t1.split(":")[1])
        c2hour=int(t2.split(":")[0])
        c2minute=int(t2.split(":")[1])
        s_h=c1hour-c2hour
        if c2hour==0:
            s_h=24-s_h 
        s_m=c1minute-c2minute
        if s_h<0:
            s_h+=24
        if s_m <0:
            s_m+=60
            s_h-=1
            if s_h<0:
                s_h=0
        if s_h==24:
            s_h=0
        convert_to_time=datetime(1,1,1,s_h,s_m, 0)
        return self._get_float_from_time(convert_to_time)
    def get_match_shift(self,current_time, current_student):
        emp_rec=self.env['res.partner'].browse(current_student)
        resource_sch_obj=emp_rec.resource_calendar_id
        tz2 = pytz.timezone(resource_sch_obj.tz)
        attend_date_nowp=datetime.strptime(current_time,'%Y-%m-%d %H:%M:%S')
        attend_date_now=attend_date_nowp
        current_time_tz=pytz.utc.localize(attend_date_now).astimezone(tz2).replace(tzinfo=None)
        checkin_min=resource_sch_obj.shift_early_checkin
        checkout_max=resource_sch_obj.shift_after_checkout
        dayname=attend_date_now.weekday()
        current_time_float=self._get_float_from_time(current_time_tz)
        current_shift=False
        for sh in resource_sch_obj.attendance_ids:
            if str(sh.dayofweek)==str(dayname):
                max_checkout=self.get_time_from_float(sh.hour_to)
                logging.info("time float="+str(sh.hour_to)+"_time="+str(max_checkout))
                max_checkout_time=datetime.strptime(str(max_checkout),'%H:%M:%S')
                logging.info("Time max="+str(max_checkout_time))
                # max_checkout_time=pytz.utc.localize(max_checkout_time).astimezone(tz2).replace(tzinfo=None)
                max_date=datetime(current_time_tz.year,current_time_tz.month,current_time_tz.day,max_checkout_time.hour,max_checkout_time.minute)
                logging.info("Time max="+str(max_date))
                if max_date.hour==0:
                    max_checkout_sh=max_date+timedelta(minutes=resource_sch_obj.shift_after_checkout,days=1)
                else:
                    max_checkout_sh=max_date+timedelta(minutes=resource_sch_obj.shift_after_checkout)
                logging.info("Time max2="+str(max_checkout_sh))
               
                # logging.info("compare fix times="+str(current_time_tz+"_"+str(max_checkout_sh)+"_"+str(current_time_tz <= max_checkout_sh)))
                if current_time_tz <= max_checkout_sh:
                    current_shift=sh
                    break
        return current_shift
    def search_and_fill(self,arr,shift_id,time,punch_type,logtype):
        if logtype=='check_in_out':
            if not shift_id in arr:
                arr[shift_id]=[{'time':time,'punch_type':punch_type,'shift':shift_id}]
            else:
                if punch_type!='0':
                    arr[shift_id].append({'time':time,'punch_type':punch_type,'shift':shift_id})
        else:
            if not shift_id in arr:
                arr[shift_id]=[{'time':time,'punch_type':punch_type,'shift':shift_id}]
            else:                
                arr[shift_id].append({'time':time,'punch_type':punch_type,'shift':shift_id})
        return arr

    def download_attendance(self):
        _logger.info("++++++++++++Cron Executed++++++++++++++++++++++")
        zk_attendance = self.env['zk.machine.attendance']
        att_obj = self.env['student.attendance']
        for info in self:
            machine_ip = info.name
            zk_port = info.port_no
            timeout = 15
            try:
                zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=False)
            except NameError:
                raise UserError(_("Pyzk module not Found. Please install it with 'pip3 install pyzk'."))
            conn = self.device_connect(zk)
            if conn:
                # conn.disable_device() #Device Cannot be used during this time.
                try:
                    user = conn.get_users()
                except:
                    user = False
                try:
                    attendance = conn.get_attendance()
                except:
                    attendance = False
                if attendance:
                    for each in attendance:
                        atten_time = each.timestamp
                        atten_time = datetime.strptime(atten_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                        # Extract the date from the punching_time
                        punching_day = atten_time.date()  # Get the date part of the datetime object

                        local_tz = pytz.timezone(
                            self.env.user.partner_id.tz or 'GMT')
                        local_dt = local_tz.localize(atten_time, is_dst=None)
                        utc_dt = local_dt.astimezone(pytz.utc)
                        utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
                        atten_time = datetime.strptime(
                            utc_dt, "%Y-%m-%d %H:%M:%S")
                        atten_time = fields.Datetime.to_string(atten_time)
                        if user:
                            for uid in user:
                                if uid.user_id == each.user_id:
                                    get_user_id = self.env['res.partner'].search(
                                        [('device_id', '=', each.user_id)])
                                    if get_user_id:
                                        duplicate_atten_ids = zk_attendance.search(
                                            [('device_id', '=', each.user_id), ('punching_time', '=', atten_time)])
                                        if duplicate_atten_ids:
                                            continue
                                        else:
                                            # Create a record in zk.machine.attendance
                                            zk_attendance.create({'student_id': get_user_id.id,
                                                                  'device_id': each.user_id,
                                                                  'attendance_type': str(each.status),
                                                                  'punch_type': str(each.punch),
                                                                  'punching_time': atten_time,
                                                                  'address_id': info.address_id.id,
                                                                  'punching_day': punching_day,
                                                                #   'address_id':each.address_id.id,
                                                                        })
                                            
                                            
                                            # Apply your logic to create student.attendance records
                                            c_date = atten_time.split(" ")
                                            c_date[0]=c_date[0].replace("-","/")
                                            emp = get_user_id
                                            machine_ip = info
                                            # ... Your logic from the else block ...
                                            check_in_recs=self.env['zk.machine.attendance'].search([('punching_day','=',c_date[0])
                                                ,('student_id','=',emp.id),('is_process','=',False), ('device_id','=',machine_ip.id)],
                                                order='punching_time')

                                            new_att=False
                                            att_arr={}

                                            for rec in check_in_recs:
                                                match_shift_computed=self.get_match_shift(str(rec.punching_time),emp.id)
                                                logging.info("match shift=="+str(match_shift_computed))
                                                if match_shift_computed:
                                                                 
                                                    att_arr=self.search_and_fill(att_arr,match_shift_computed.id,rec.punching_time,rec.punch_type,self.log_by_check_in_check_out)
                                                    rec.is_process=True
                                                    logging.info("attr===="+str(att_arr))
                                                    for key,rec_shift in att_arr.items():
                                                        new_att=False
                                                        delay_totalminutes=0
                                                        if len(rec_shift)>1:
                                                            i=0
                                                            psave=False
                                                            for punch_rec in rec_shift:
                                                                if i==0:
                                                                    shift_obj=self.env['resource.calendar.attendance'].browse(punch_rec['shift'])
                                                                    new_att=self.env['student.attendance'].create({'student_id': emp.id,
                                                                                'check_in': punch_rec['time'],
                                                                                'shift_rec':punch_rec['shift'],
                                                                                'expected_check_in':shift_obj.hour_from,
                                                                                'expected_check_out':shift_obj.hour_to,
                                                                            #  'address_id':each.address_id.id,
                                                                                })
                                                                    i+=1
                                                                else:                            
                                                                    psave=punch_rec
                                                                    f_time=self._get_float_from_time(punch_rec['time'])
                                                                    logging.info(">>>>>coppare="+str(f_time)+"__"+str((shift_obj.hour_to+emp.resource_calendar_id.shift_after_checkout))+"__"+str(new_att.check_in))
                                                                    if (shift_obj.hour_to+emp.resource_calendar_id.shift_after_checkout)<f_time:
                                                                        break
                                                            if psave:
                                                                logging.info("all data="+str(psave['time'])+"__"+str(new_att.check_in))
                                                                delay_totalminutes=self.subtract_two_times_24h(self._get_float_from_time(psave['time']),self._get_float_from_time(new_att.check_in))
                                                                dd=psave['time']-new_att.check_in
                                                                logging.info(">>>>"+str(dd)+"_"+str(psave['time'])+"_"+str(new_att.check_in))
                                                                hours_per_day=emp.resource_calendar_id.hours_per_day
                                                                delay_totalminutes=hours_per_day-delay_totalminutes
                                                                new_att.write({ 'check_out': psave['time'],
                                                                                'is_process':True,
                                                                                'act_diff_time':delay_totalminutes,
                                                                            
                                                                            })
                                                        else:
                                                            for punch_rec in rec_shift:
                                                                shift_obj=self.env['resource.calendar.attendance'].browse(punch_rec['shift'])
                                                                new_att=self.env['student.attendance'].create({'student_id': emp.id,
                                                                                'check_in': punch_rec['time'],
                                                                                'shift_rec':punch_rec['shift'],
                                                                                'expected_check_in':shift_obj.hour_from,
                                                                                'expected_check_out':shift_obj.hour_to,
                                                                                })
                                            else:
                                                print('ddfcd', str(each.status))
                                                print('user', uid.name)
                                                student = self.env['res.partner'].create(
                                                    {'device_id': each.user_id, 'name': uid.name})
                                                zk_attendance.create({'student_id': student.id,
                                                                    'device_id': each.user_id,
                                                                    'attendance_type': str(each.status),
                                                                    'punch_type': str(each.punch),
                                                                    'punching_time': atten_time,
                                                                    'address_id': info.address_id.id})
                                                att_obj.create({'student_id': student.id,
                                                            'check_in': atten_time})
                                    else:
                                        pass
                        # zk.enableDevice()
                        conn.disconnect
                        return True
                else:
                    raise UserError(_('Unable to get the attendance log, please try again later.'))
            else:
                raise UserError(_('Unable to connect, please check the parameters and network connections.'))
    ##----------------------------------------------------------------------------------------------------------------------------------------------------------
    def action_sync_attendance(self):
        """Synchronizes attendance data from ZKTeco system with Odoo HR."""

        sync_days = int(self.env['ir.config_parameter'].sudo().get_param('hr_attendance_zkteco.sync_days'))
        # Get the current date and calculate the date range
        date_to = date.today()
        date_from = date_to - timedelta(days=sync_days)
        # Retrieve attendance records from ZK system
        zk_attendance_records = self.env['zk.report.daily.attendance'].search(
            [('punching_time', '>=', date_from), ('punching_time', '<=', date_to)]
        )
        # Group attendance records by student
        student_attendance_records = {}
        for record in zk_attendance_records:
            student_id = record.student_id.id
            if student_id not in student_attendance_records:
                student_attendance_records[student_id] = []
            student_attendance_records[student_id].append(record)
        # Iterate through students and synchronize attendance records
        for student_id, records in student_attendance_records.items():
            student = self.env['res.partner'].browse(student_id)
            try:
                self._sync_student_attendance(student, records)
            except Exception as e:
                _logger.error("Error synchronizing attendance for student %s: %s", student.name, e)
    # Private method to synchronize student attendance
    def _sync_student_attendance(self, student, zk_attendance_records):
        """Synchronizes attendance records for a specific student."""

        hr_attendance = self.env['student.attendance']

        # Sort attendance records by punching time
        zk_attendance_records = sorted(zk_attendance_records, key=lambda x: x.punching_time)

        # Iterate through ZK attendance records
        for i, zk_record in enumerate(zk_attendance_records):
            # Check if attendance record already exists in Odoo HR
            existing_record = hr_attendance.search(
                [
                    ('student_id', '=', student.id),
                    ('check_in', '=', zk_record.punching_time),
                ],
                limit=1,
            )
            if existing_record:
                # Update existing record with ZK data
                existing_record.write({
                    # Update fields based on ZK data
                })
            else:
                # Create new attendance record in Odoo HR
                # Determine check_out based on the next record
                check_out = None
                if i < len(zk_attendance_records) - 1:
                    next_record = zk_attendance_records[i + 1]
                    check_out = next_record.punching_time
                hr_attendance.create({
                    'student_id': student.id,
                    'check_in': zk_record.punching_time,
                    'check_out': check_out,
                    # Add other relevant fields
                })
    

    # ==================================move_unmoved_checks_2 SYNC this is correcting attendance ==============================
    
    def move_unmoved_checks_2(self):
        _logger.info("++++++++++++Moving Unmoved Checks updatesd checkout ++++++++++++++++++++++")
        zk_attendance = self.env['zk.machine.attendance']
        att_obj = self.env['student.attendance']

        for info in self:
            machine_ip = info.name
            zk_port = info.port_no
            timeout = 15

            try:
                zk = ZK(machine_ip, port=zk_port, timeout=timeout, password=0, force_udp=False, ommit_ping=False)
            except NameError:
                raise UserError(_("Pyzk module not Found. Please install it with 'pip3 install pyzk'."))

            conn = self.device_connect(zk)
            if conn:
                try:
                    attendance = conn.get_attendance()
                except:
                    attendance = False

                try:
                    user = conn.get_users()
                except:
                    user = False

                if attendance:
                    attendance_data = []
                    hr_attendance_data = {}  # Use a dictionary to store attendance data by student and date

                    for each in attendance:
                        atten_time = each.timestamp
                        atten_time = datetime.strptime(atten_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                        local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
                        local_dt = local_tz.localize(atten_time, is_dst=None)
                        utc_dt = local_dt.astimezone(pytz.utc)
                        atten_time = utc_dt.replace(tzinfo=None)

                        if user:
                            for uid in user:
                                if uid.user_id == each.user_id:
                                    get_user_id = self.env['res.partner'].search([('device_id', '=', each.user_id)])
                                    if get_user_id:
                                        attendance_date = atten_time.date()
                                        student_ids = get_user_id
                                        if len(student_ids) == 1:
                                            student_id = student_ids.id
                                        elif len(student_ids) > 1:
                                            _logger.error("get_user_id contains multiple records: %s", student_ids)
                                            student_id = student_ids[0].id
                                        else:
                                            student_id = student_ids.id
                                            _logger.error("get_user_id contains multiple records: %s", student_ids)
                                            return

                                        if student_id not in hr_attendance_data:
                                            hr_attendance_data[student_id] = {}

                                        if attendance_date not in hr_attendance_data[student_id]:
                                            # First attendance of the day, set both check_in and check_out
                                            hr_attendance_data[student_id][attendance_date] = {
                                                'check_in': atten_time,
                                                'check_out': atten_time
                                            }
                                        else:
                                            # Update check_out if it's a later time on the same day
                                            if hr_attendance_data[student_id][attendance_date]['check_out'] is not None:
                                                if atten_time > hr_attendance_data[student_id][attendance_date]['check_out']:
                                                    hr_attendance_data[student_id][attendance_date]['check_out'] = atten_time
                                        # Check for existing record (considering all records in zk_attendance)
                                        existing_record = zk_attendance.search([
                                            ('student_id', '=', student_id),
                                            ('device_id', '=', each.user_id),
                                            ('punching_time', '=', atten_time)
                                        ])
                                        existing_record1 = att_obj.search([
                                            ('student_id', '=', student_id),
                                            ('device_id', '=', each.user_id),
                                            ('check_in', '=', atten_time)
                                        ])
                                        # If no existing record, create a new one
                                        if not (existing_record or existing_record1):
                                            attendance_data.append({
                                                'student_id': student_id,
                                                'device_id': each.user_id,
                                                'attendance_type': str(each.status),
                                                'punch_type': str(each.punch),
                                                'punching_time': atten_time,
                                                'address_id': info.address_id.id
                                            })
                                    else:
                                        # Create a new res.partner record
                                        student = self.env['res.partner'].create({
                                            'device_id': each.user_id,
                                            'name': uid.name
                                        })

                                        # Check for existing record (considering all records in zk_attendance)
                                        existing_record = zk_attendance.search([
                                            ('student_id', '=', student.id),
                                            ('device_id', '=', each.user_id),
                                            ('punching_time', '=', atten_time)
                                        ])
                                        existing_record1 = att_obj.search([
                                            ('student_id', '=', student.id),
                                            ('device_id', '=', each.user_id),
                                            ('check_in', '=', atten_time)
                                        ])
                                         

                                        # If no existing record, create a new one
                                        if not (existing_record or existing_record1):  
                                            attendance_data.append({
                                                'student_id': student.id,
                                                'device_id': each.user_id,
                                                'attendance_type': str(each.status),
                                                'punch_type': str(each.punch),
                                                'punching_time': atten_time,
                                                'address_id': info.address_id.id
                                            })
                                            #add this after error 
                                            attendance_date = atten_time.date()
                                            hr_attendance_data[student.id] = {
                                                attendance_date: {
                                                    'check_in': atten_time,
                                                    'check_out': atten_time
                                                }
                                            }
                                else:
                                    pass
                    
                    existing_record = zk_attendance.search([
                        ('student_id', '=', student_id),
                        ('device_id', '=', each.user_id),
                        ('punching_time', '=', atten_time)
                    ])
                    existing_record1 = att_obj.search([
                        ('student_id', '=', student_id),
                        ('device_id', '=', each.user_id),
                        ('check_in', '=', atten_time)
                    ])

                    # If no existing record, create a new one
                    if not (existing_record or existing_record1):

                        zk_attendance.create(attendance_data)

                        # Create student.attendance records from the filtered data
                        for student_id, dates in hr_attendance_data.items():
                            for attendance_date, times in dates.items():
                                hr_attendance_data = {
                                    'student_id': student_id,
                                    'check_in': times['check_in'],
                                    'check_out': times['check_out']
                                }
                                att_obj.create(hr_attendance_data)

                conn.disconnect()
                return True
            else:
                raise UserError(_('Unable to connect, please check the parameters and network connections.'))