## Module <hr_zk_attendance>

#### 16.11.2023
#### Version 17.0.1.0.0
##### ADD

- Initial commit for Biometric Device Integration

#### 31.07.2024
#### Version 17.0.1.1.1
##### UPDT

- Added a new feature to Set the timezone for the device.

#### 31.07.2024
#### Version 17.0.1.2.2
##### UPDT

- Added a new feature to schedule attendance downloading
