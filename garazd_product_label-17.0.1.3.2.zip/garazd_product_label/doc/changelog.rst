.. _changelog:

Changelog
=========

`17.0.1.3.2`
------------

- Change button styles.

- Add method to get PDF.

`17.0.1.3.1`
------------

- Add UA translations.

`17.0.1.3.0`
------------

- Add a new model to specify label types.

- Add the blank product for technical purposes.

- Add the "Custom Value" field for print lines to use in label templates.

- Add a technical field "Partner" to label lines.

`17.0.1.2.0`
------------

- Add a method to get a label report action.

- Refactor XML actions to open the label printing wizard.

`17.0.1.1.0`
------------

- Improve getting of labels to print, add excluding of lines with qty=0.

- Add the "mode" option for technical purposes.

`17.0.1.0.0`
------------

- Migration from 16.0.


