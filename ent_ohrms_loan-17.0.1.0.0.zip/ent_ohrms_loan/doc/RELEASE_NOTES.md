## Module <ent_ohrms_loan>

#### 30.01.2024
#### Version 17.0.1.0.0
##### ADD

- Initial commit for Enterprise OpenHRMS Loan Management 
