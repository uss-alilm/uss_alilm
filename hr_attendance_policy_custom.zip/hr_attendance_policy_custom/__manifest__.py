{
    'name': 'HR Attendance Policy Custom',
    'version': '17.0.1.0.0',
    'author': 'Your Company',
    'category': 'Human Resources',
    'summary': 'Custom attendance policy management for employees',
    'depends': [
        'hr',            # needed for hr.employee model
        'hr_attendance', # if you are using the attendance app
    ],
    'data': [
        # XML data files (views, security rules, etc.)
        'security/ir.model.access.csv',
        'views/hr_attendance_policy_views.xml',
        'views/hr_employee_views.xml',
    ],
    'installable': True,
    'application': False,
}
