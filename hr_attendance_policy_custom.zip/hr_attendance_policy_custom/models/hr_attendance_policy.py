from odoo import fields, models, api

class HrAttendancePolicy(models.Model):
    _name = 'hr.attendance.policy'
    _description = 'Attendance Policy'

    name = fields.Char(string='Policy Name', required=True)
    active = fields.Boolean(string='Active', default=True)
    policy_line_ids = fields.One2many(
        'hr.attendance.policy.line',
        'policy_id',
        string='Policy Lines'
    )
    # You can store additional settings here (e.g. flexible or not,
    # default daily hours, or anything relevant for the entire policy)

class HrAttendancePolicyLine(models.Model):
    _name = 'hr.attendance.policy.line'
    _description = 'Attendance Policy Line'

    policy_id = fields.Many2one(
        'hr.attendance.policy',
        string='Policy',
        required=True,
        ondelete='cascade'
    )
    # For day of the week, store values from 0 (Monday) to 6 (Sunday)
    day_of_week = fields.Selection([
        ('0', 'Monday'),
        ('1', 'Tuesday'),
        ('2', 'Wednesday'),
        ('3', 'Thursday'),
        ('4', 'Friday'),
        ('5', 'Saturday'),
        ('6', 'Sunday'),
    ], string='Day of Week', required=True)

    required_hours = fields.Float(string='Required Hours', help='Total required hours for this day')

    # Morning session
    morning_start = fields.Float(string='Morning Start', help='Start time in hours (e.g. 8.0 for 8:00 AM)')
    morning_end = fields.Float(string='Morning End', help='End time in hours (e.g. 12.0 for 12:00 PM)')

    # Evening session
    evening_start = fields.Float(string='Evening Start')
    evening_end = fields.Float(string='Evening End')

    # For flexible or open attendance logic, you can add flags or extra fields:
    is_flexible = fields.Boolean(string='Flexible Hours?', default=False)

    @api.onchange('morning_start', 'morning_end', 'evening_start', 'evening_end')
    def _onchange_time_check(self):
        # Optional: Validate that the times are logically correct
        if (self.morning_start and self.morning_end) and (self.morning_end < self.morning_start):
            return {
                'warning': {
                    'title': 'Warning',
                    'message': 'Morning end time cannot be before start time.'
                }
            }
        if (self.evening_start and self.evening_end) and (self.evening_end < self.evening_start):
            return {
                'warning': {
                    'title': 'Warning',
                    'message': 'Evening end time cannot be before start time.'
                }
            }


class HrAttendance(models.Model):
    _inherit = 'hr.attendance'

    def _compute_policy_hours(self):
        for attendance in self:
            policy = attendance.employee_id.attendance_policy_id
            if policy:
                # figure out day of week
                day_index = attendance.check_in.weekday()  # 0=Monday, 6=Sunday
                # find matching line
                line = policy.policy_line_ids.filtered(lambda l: int(l.day_of_week) == day_index)
                if line:
                    # You can do calculations here
                    # e.g. how many hours required, flexible or not, etc.
                    pass
